import React, { Component } from 'react';
import logo from './logo.svg';
import gufskyLogo from './gufskyLogo.png'
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h2>Hello World</h2>
        </div>
        <p className="App-intro">
          Making react apps can be fun.
        </p>
        <img src={gufskyLogo} className="App-logo" alt="Gufsky_logo" />
      </div>
    );
  }
}

export default App;
